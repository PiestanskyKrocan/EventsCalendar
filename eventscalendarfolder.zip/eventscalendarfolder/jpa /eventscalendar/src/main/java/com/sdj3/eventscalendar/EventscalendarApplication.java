package com.sdj3.eventscalendar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventscalendarApplication {

    public static void main(String[] args) {
        SpringApplication.run(EventscalendarApplication.class, args);
    }

}
