package org.example.client;

public class Client {
    
}
